import 'package:flutter/material.dart';

import '../generated/l10n.dart';

class MyDrawer extends StatelessWidget {
  const MyDrawer({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: SafeArea(
        child: Column(children: [
          const CircleAvatar(
            child: Text('AB'),
            radius: 75,
          ),
          const Divider(
            indent: 20,
            endIndent: 20,
            height: 50,
          ),
          Padding(
            padding: const EdgeInsets.only(left: 25),
            child: ListTile(
              title: Text(S.of(context).DrawerProflie),
              leading: const Icon(Icons.person_2_outlined),
              onTap: () {
                Navigator.popAndPushNamed(context, '/accs');
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 25, top: 25),
            child: ListTile(
              title: Text(S.of(context).DrawerCart),
              leading: const Icon(Icons.shopping_cart_outlined),
              onTap: () => Navigator.pushNamed(context, '/cart'),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 25, top: 25),
            child: ListTile(
              title: Text(S.of(context).DrawerFav),
              leading: const Icon(Icons.star_border_outlined),
              onTap: () => Navigator.pushNamed(context, '/favorites'),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 25, top: 25),
            child: ListTile(
              title: Text(S.of(context).DrawerHistory),
              leading: const Icon(Icons.history_outlined),
              onTap: () => Navigator.pushNamed(context, '/orderhist'),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 25, top: 25),
            child: ListTile(
              title: Text(S.of(context).DrawerSet),
              leading: const Icon(Icons.settings_outlined),
              onTap: () => Navigator.pushNamed(context, "/set"),
            ),
          ),
          Spacer(),
          Padding(
            padding: const EdgeInsets.only(left: 25, top: 25),
            child: ListTile(
              title: Text(S.of(context).logout),
              leading: const Icon(Icons.logout),
              onTap: () => Navigator.pushNamed(context, "/login"),
            ),
          ),
        ]),
      ),
    );
  }
}
