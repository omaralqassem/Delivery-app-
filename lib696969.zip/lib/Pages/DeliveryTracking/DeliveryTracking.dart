import 'package:flutter/material.dart';
import 'MyTimeline.dart';
import '../../generated/l10n.dart';

class Delivery extends StatelessWidget {
  const Delivery({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: const Icon(Icons.arrow_back_ios),
        ),
        centerTitle: true,
        title: Text(S.of(context).TrackingTitle),
      ),
      body: ListView(
        children: [
          Container(
            height: 250,
            decoration: const BoxDecoration(
                boxShadow: [BoxShadow(spreadRadius: 1, blurRadius: 1)],
                color: Color.fromARGB(207, 227, 255, 151),
                borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(50),
                    bottomRight: Radius.circular(50))),
            child: const Image(image: AssetImage('assets/photos/tracking.png')),
          ),
          MyTimeline(
              isDone: true,
              st: S.of(context).TrackingPlaced,
              isFirst: true,
              isLast: false),
          MyTimeline(
              isDone: false,
              st: S.of(context).TrackingITW,
              isFirst: false,
              isLast: false),
          MyTimeline(
              isDone: false,
              st: S.of(context).TrackingDone,
              isFirst: false,
              isLast: true),
          Container(
            padding: EdgeInsets.fromLTRB(25, 0, 0, 0),
            child: Text(S.of(context).TrackingDetails),
          ),
          const SizedBox(
            height: 140,
          ),
        ],
      ),
    );
  }
}
