import 'package:flutter/material.dart';
import '../generated/l10n.dart';

class PaymentPage extends StatefulWidget {
  const PaymentPage({super.key});

  @override
  State<PaymentPage> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<PaymentPage> {
  bool _isAsapDeliverySelected = true;
  String _selectedAddress = "Jaramana";
  String _selectedPaymentMethod = "Cash";

  final List<String> _addresses = [
    "Rukn Aldeen",
    "Jaramana",
    "BabToma",
    "Almidan",
    "Alsalhiah",
    "Abu Romaneh",
    "Alshaalan",
    "Other",
  ];

  final List<String> _paymentMethods = [
    "Cash",
    "Visa",
    "Card",
    "Syriatel Cash",
  ];

  void _selectAddress(String? address) {
    if (address != null) {
      setState(() {
        _selectedAddress = address;
      });
    }
  }

  void _selectPaymentMethod(String? method) {
    if (method != null) {
      setState(() {
        _selectedPaymentMethod = method;
      });
    }
  }

  void _onScheduledDateChange(String date) {
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: const Icon(Icons.arrow_back_ios),
        ),
        centerTitle: true,
        title: Text(S.of(context).Checkout),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                S.of(context).DeliveryTime,
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              Row(
                children: [
                  Radio(
                    value: true,
                    groupValue: _isAsapDeliverySelected,
                    onChanged: (value) {
                      setState(() {
                        _isAsapDeliverySelected = true;
                      });
                    },
                  ),
                  Text(S.of(context).ASAP),
                ],
              ),
              Row(
                children: [
                  Radio(
                    value: false,
                    groupValue: _isAsapDeliverySelected,
                    onChanged: (value) {
                      setState(() {
                        _isAsapDeliverySelected = false;
                      });
                    },
                  ),
                  Text(S.of(context).Schd),
                ],
              ),
              if (!_isAsapDeliverySelected)
                TextField(
                  keyboardType: TextInputType.datetime,
                  decoration: const InputDecoration(
                    hintText: 'DD/MM/YYYY',
                    border: OutlineInputBorder(),
                  ),
                  onChanged: _onScheduledDateChange,
                ),
              const SizedBox(height: 20),
              Text(
                S.of(context).MyAD,
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              DropdownButtonFormField<String?>(
                value: _selectedAddress,
                items: _addresses.map((address) {
                  return DropdownMenuItem<String?>(
                    value: address,
                    child: Text(address),
                  );
                }).toList(),
                onChanged: _selectAddress,
              ),
              const SizedBox(height: 10),
              TextField(
                decoration: InputDecoration(
                  hintText: S.of(context).AddressDetails,
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 20),
              Text(
                S.of(context).PayWith,
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              DropdownButtonFormField<String?>(
                value: _selectedPaymentMethod,
                items: _paymentMethods.map((method) {
                  return DropdownMenuItem<String?>(
                    value: method,
                    child: Text(method),
                  );
                }).toList(),
                onChanged: _selectPaymentMethod,
              ),
              const SizedBox(height: 20),
              Text(
                S.of(context).DeliveryFee,
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 5),
              const Text(
                '10 \$',
              ),
              const SizedBox(height: 20),
              Text(
                S.of(context).fp,
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomAppBar(
        child: SizedBox(
          height: 60,
          child: Center(
            child: ElevatedButton(
              onPressed: () {
                showDialog(
                  context: context,
                  builder: (context) => AlertDialog(
                    title: Text(S.of(context).PAS),
                    content: Text(S.of(context).Oplaced),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.of(context).pop(),
                        child: Text(S.of(context).OK),
                      ),
                    ],
                  ),
                );
              },
              child: Text(
                S.of(context).PlaceOrder,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
