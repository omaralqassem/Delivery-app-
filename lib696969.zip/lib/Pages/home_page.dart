import 'package:flutter/material.dart';
import '../components/bottom_sheet.dart';
import '../Pages/store_page.dart';
import '../components/my_drawer.dart';
import '../generated/l10n.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

List<String> storeNames = [];
List<int> storeId = [];
List<String> storesImages = [];

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePage();
}

class _HomePage extends State<HomePage> {
  bool isLoading = true;
  Future<void> fetchStores() async {
    try {
      final response =
          await http.get(Uri.parse('http://10.0.2.2:8000/api/stores'));
      if (response.statusCode == 200) {
        final List<dynamic> data = json.decode(response.body);
        print(response.body);
        setState(() {
          storeId = data.map((store) => store['id'] as int).toList();
          storeNames = data.map((store) => store['name'] as String).toList();
          storesImages = data.map((store) => store['image'] as String).toList();
          isLoading = false;
        });
        print(storesImages);
      } else {
        setState(() {
          isLoading = false;
        });
      }
    } catch (e) {
      print("Error fetching stores: $e");
      setState(() {
        isLoading = false;
      });
    }
  }

  List<Map<String, dynamic>> selectedProducts = [];

  Future<void> fetchAndSortProducts() async {
    try {
      final List<Map<String, dynamic>> allProducts = [];
      for (int storeId in storeId) {
        final response = await http
            .get(Uri.parse('http://10.0.2.2:8000/api/stores/$storeId'));
        if (response.statusCode == 200) {
          final Map<String, dynamic> storeData = json.decode(response.body);
          final List<dynamic> products = storeData['products'];
          allProducts.addAll(
              products.map((product) => product as Map<String, dynamic>));
        }
      }

      allProducts
          .sort((a, b) => (b['stock'] as int).compareTo(a['stock'] as int));

      setState(() {
        selectedProducts = allProducts.take(6).toList();
      });
    } catch (e) {
      print("Error fetching and sorting products: $e");
    }
  }

  @override
  void initState() {
    super.initState();
    fetchStores();
    fetchAndSortProducts();
    print(selectedProducts);
  }

  @override
  Widget build(BuildContext context) {
    print(storesImages);

    return Scaffold(
        drawer: const MyDrawer(),
        body: NestedScrollView(
          floatHeaderSlivers: true,
          headerSliverBuilder: (BuildContext context, bool innerBoxIsScrolled) {
            return <Widget>[
              SliverAppBar(
                automaticallyImplyLeading: false,
                title: Row(
                  children: <Widget>[
                    Expanded(
                      child: TextField(
                        keyboardType: TextInputType.text,
                        textInputAction: TextInputAction.go,
                        decoration: InputDecoration(
                            filled: true,
                            focusedBorder: const OutlineInputBorder(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(50))),
                            enabledBorder: const OutlineInputBorder(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(50))),
                            contentPadding:
                                const EdgeInsets.symmetric(horizontal: 15),
                            hintText: S.of(context).HPSearch,
                            prefixIcon: IconButton(
                                onPressed: () =>
                                    Scaffold.of(context).openDrawer(),
                                icon: const Icon(Icons.menu)),
                            suffixIcon: IconButton(
                              icon: Icon(Icons.shopping_bag_outlined),
                              onPressed: () =>
                                  Navigator.pushNamed(context, '/delivery'),
                            )),
                      ),
                    ),
                  ],
                ),
                floating: true,
              ),
            ];
          },
          body: isLoading
              ? Center(child: CircularProgressIndicator())
              : ListView(padding: const EdgeInsets.all(0), children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: EdgeInsets.all(8.0),
                        child: Text(
                          S.of(context).HPH1,
                          style: TextStyle(
                              fontSize: 20, fontWeight: FontWeight.w700),
                        ),
                      ),
                      SizedBox(
                        height: 200,
                        child: ListView.builder(
                          scrollDirection: Axis.horizontal,
                          itemCount: storeNames.length,
                          itemBuilder: (context, index) {
                            return Padding(
                              padding: const EdgeInsets.all(4.0),
                              child: GestureDetector(
                                child: Card(
                                  color: Color.fromARGB(207, 227, 255, 151),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: LayoutBuilder(
                                      builder: (context, constraints) {
                                    return Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Stack(
                                          children: [
                                            ClipRRect(
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                              child: Container(
                                                width: constraints.maxHeight,
                                                height: constraints.maxHeight,
                                                decoration: BoxDecoration(
                                                    boxShadow: const [
                                                      BoxShadow(
                                                          spreadRadius: 1,
                                                          blurRadius: 5)
                                                    ],
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            12.0),
                                                    image: DecorationImage(
                                                        image: NetworkImage(
                                                          'http://10.0.2.2:8000/storage/${storesImages[index]}',
                                                        ),
                                                        fit: BoxFit.fill)),
                                                // child: Image.network(
                                                //   'http://10.0.2.2:8000/storage/${storesImages[index]}',
                                                //   fit: BoxFit.cover,
                                                // ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    );
                                  }),
                                ),
                                onTap: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => StorePage(
                                        storeName: storeNames[index],
                                        storeId: storeId[index],
                                        storeImage: storesImages[index],
                                      ),
                                    ),
                                  );
                                },
                              ),
                            );
                          },
                        ),
                      ),
                      const SizedBox(height: 10),
                      Padding(
                        padding: EdgeInsets.all(8.0),
                        child: Text(
                          S.of(context).HPH2,
                          style: TextStyle(
                              fontSize: 20, fontWeight: FontWeight.w700),
                        ),
                      ),
                      SizedBox(
                        height: 400,
                        child: selectedProducts.isEmpty
                            ? const Center(child: CircularProgressIndicator())
                            : GridView.builder(
                                padding: const EdgeInsets.all(0),
                                gridDelegate:
                                    const SliverGridDelegateWithFixedCrossAxisCount(
                                  crossAxisCount: 2,
                                ),
                                scrollDirection: Axis.vertical,
                                itemCount: selectedProducts.length,
                                itemBuilder: (context, index) {
                                  final product = selectedProducts[index];
                                  return GestureDetector(
                                    onTap: () {
                                      showbottomsheet(context, product);
                                    },
                                    child: Padding(
                                      padding: const EdgeInsets.all(4.0),
                                      child: Card(
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Stack(
                                              children: [
                                                Container(
                                                  margin: const EdgeInsets.only(
                                                      left: 15.0),
                                                  height: 140.0,
                                                  width: 150.0,
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            12.0),
                                                    image: DecorationImage(
                                                      image: NetworkImage(
                                                        product['image'] !=
                                                                    null &&
                                                                product['image']
                                                                    .isNotEmpty
                                                            ? "http://10.0.2.2:8000/storage/${product['image']}"
                                                            : 'assets/images/placeholder.jpg',
                                                      ),
                                                      fit: BoxFit.contain,
                                                    ),
                                                    shape: BoxShape.rectangle,
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Padding(
                                              padding: const EdgeInsets.only(
                                                  left: 20),
                                              child: Column(
                                                children: [
                                                  Text(
                                                    product['name'],
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                  ),
                                                  Text(
                                                    "\$${product['price']}",
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  );
                                },
                              ),
                      ),
                      Padding(
                        padding: EdgeInsets.all(8.0),
                        child: Text(
                          S.of(context).HPH3,
                          style: TextStyle(
                              fontSize: 20, fontWeight: FontWeight.w700),
                        ),
                      ),
                      SizedBox(
                        height: 400,
                        child: GridView.builder(
                          padding: const EdgeInsets.all(0),
                          gridDelegate:
                              const SliverGridDelegateWithFixedCrossAxisCount(
                                  crossAxisCount: 2),
                          scrollDirection: Axis.vertical,
                          itemCount: 6,
                          itemBuilder: (context, index) {
                            return Padding(
                              padding: const EdgeInsets.all(4.0),
                              child: Card(
                                  child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Stack(
                                    children: [
                                      Image.asset(
                                        'assets/photos/sneaker.png',
                                        fit: BoxFit.cover,
                                      ),
                                      Positioned(
                                        top: 12,
                                        left: 12,
                                        child: Container(
                                          padding: EdgeInsets.all(2),
                                          decoration: BoxDecoration(
                                              color: Colors.yellow,
                                              borderRadius:
                                                  BorderRadius.circular(8)),
                                          child: const ClipRRect(
                                            child: Text(
                                              '25%',
                                            ),
                                          ),
                                        ),
                                      )
                                    ],
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(left: 20),
                                    child: Column(
                                      children: [
                                        Text(
                                          "Product $index",
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                        Text(
                                          "Product $index",
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              )),
                            );
                          },
                        ),
                      ),
                      const SizedBox(
                        height: 500,
                      ),
                    ],
                  ),
                ]),
        ));
  }
}
