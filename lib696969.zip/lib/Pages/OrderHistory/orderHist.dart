import 'package:flutter/material.dart';
import '../../generated/l10n.dart';
import 'ParsingOrders.dart';
import 'dart:convert';
import 'package:flutter/services.dart';

class OrderHist extends StatefulWidget {
  const OrderHist({Key? key}) : super(key: key);

  @override
  OrderHistory createState() => OrderHistory();
}

class OrderHistory extends State<OrderHist> {
  List<Orders> acOrders = [];
  List<Orders> _items = [];
  String targetCustomer = 'Jane Lot';

  // Fetch content from the json file
  Future<void> readJson() async {
    final String response =
        await rootBundle.loadString('assets/orderhist.json');
    final data = await json.decode(response);

    final List<Orders> ordersList = (data['orders'] as List)
        .map((orderJson) => Orders.fromJson(orderJson))
        .toList();

    // Filter orders for the target customer
    final filteredOrders = ordersList
        .where((order) => order.customerName == targetCustomer)
        .toList();

    setState(() {
      _items = filteredOrders;
    });
  }

  @override
  void initState() {
    super.initState();
    readJson();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: const Icon(Icons.arrow_back_ios),
        ),
        centerTitle: true,
        title: Text(S.of(context).OrderHisT),
      ),
      body: Padding(
        padding: const EdgeInsets.all(4.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.fromLTRB(10, 0, 0, 0),
              child: Text(
                S.of(context).ActivOr,
                style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            acOrders.isEmpty
                ? Center(child: Text(S.of(context).NoActiveO))
                : Expanded(
                    child: ListView.builder(
                      itemCount: _items.length,
                      itemBuilder: (BuildContext context, int index) {
                        final order = _items[index];
                        return Card(
                          semanticContainer: true,
                          margin: const EdgeInsets.all(15),
                          elevation: 5,
                          borderOnForeground: true,
                          // shadowColor: const Color(0xff07120F),
                          child: ListTile(
                            title: Text(order.orderId),
                            subtitle: Text('Order Date: ${order.orderDate}'),
                            trailing: Text(
                                '\$${order.totalPrice.toStringAsFixed(2)}'),
                          ),
                        );
                      },
                    ),
                  ),
            const Divider(
              thickness: 2,
              height: 3,
            ),
            const SizedBox(height: 5),
            Container(
              padding: const EdgeInsets.fromLTRB(10, 0, 0, 0),
              child: Text(
                S.of(context).PastOrder,
                style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            _items.isEmpty
                ? Center(child: Text(S.of(context).NoPastOrd))
                : Expanded(
                    child: ListView.builder(
                      itemCount: _items.length,
                      itemBuilder: (BuildContext context, int index) {
                        final order = _items[index];
                        return Card(
                          semanticContainer: true,
                          margin: const EdgeInsets.all(15),
                          elevation: 5,
                          borderOnForeground: true,
                          // shadowColor: const Color(0xff7ecd79),
                          child: ListTile(
                            title: Text(order.orderId),
                            subtitle: Text('Order Date: ${order.orderDate}'),
                            trailing: Text(
                                '\$${order.totalPrice.toStringAsFixed(2)}'),
                          ),
                        );
                      },
                    ),
                  ),
          ],
        ),
      ),
    );
  }
}
