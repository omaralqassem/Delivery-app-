class Orders {
  final String orderId;
  final String customerName;
  final DateTime orderDate;
  final double totalPrice;
  final List<Product> products;

  Orders({
    required this.orderId,
    required this.customerName,
    required this.orderDate,
    required this.totalPrice,
    required this.products,
  });
  factory Orders.fromJson(Map<String, dynamic> json) {
    final List<Product> products = (json['products'] as List)
        .map((productJson) => Product.fromJson(productJson))
        .toList();

    return Orders(
      orderId: json['order_id'],
      customerName: json['customer_name'],
      orderDate: DateTime.parse(json['order_date']),
      totalPrice: json['total_price'].toDouble(),
      products: products,
    );
  }
}

class Product {
  final String productId;
  final String productName;
  final int quantity;
  final double unitPrice;

  Product({
    required this.productId,
    required this.productName,
    required this.quantity,
    required this.unitPrice,
  });
  factory Product.fromJson(Map<String, dynamic> json) {
    return Product(
      productId: json['product_id'],
      productName: json['product_name'],
      quantity: json['quantity'],
      unitPrice: json['unit_price'].toDouble(),
    );
  }
}
